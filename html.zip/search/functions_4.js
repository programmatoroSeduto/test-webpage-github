var searchData=
[
  ['get_5fnearest_5fhand_5fpose',['get_nearest_hand_pose',['../task__manager_8py.html#ac49e194e872defc00a319f20e511f8b0',1,'task_manager']]],
  ['get_5ftask_5farm_5fleft',['get_task_arm_left',['../task__manager_8py.html#ad57b78d9316869c56a8fb9013dcb208b',1,'task_manager']]],
  ['get_5ftask_5farm_5fright',['get_task_arm_right',['../task__manager_8py.html#a449f8a12b2333f8f74c1783dcbcdf565',1,'task_manager']]]
];
