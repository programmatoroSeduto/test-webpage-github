var searchData=
[
  ['task_20manager',['Task manager',['../md_docs__note_conclusive_sul_task_manager_a8dad796f45e480598de6d8c75cf5fe6.html',1,'']]]
];
