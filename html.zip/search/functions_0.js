var searchData=
[
  ['block_5fin_5fblue_5fgoal',['block_in_blue_goal',['../task__manager_8py.html#a170cbad37b15c240311d55af019035f9',1,'task_manager']]],
  ['block_5fin_5fred_5fgoal',['block_in_red_goal',['../task__manager_8py.html#a23ae8ed70cad2b5c9e20d2f1b6ef4edb',1,'task_manager']]],
  ['block_5fis_5faccessible',['block_is_accessible',['../task__manager_8py.html#ac14ece09edff4a0a2129e4c927c5dbea',1,'task_manager']]],
  ['block_5fnot_5fnear_5fto_5fhand',['block_not_near_to_hand',['../task__manager_8py.html#af1e0257c9dcdefaa571daa9b50ea0e83',1,'task_manager']]],
  ['block_5fon_5fleft_5ftable',['block_on_left_table',['../task__manager_8py.html#aac9687bc9fea070023b2c3d4f4a3443e',1,'task_manager']]],
  ['block_5fon_5fright_5ftable',['block_on_right_table',['../task__manager_8py.html#ab8fa180b025040365b3b0baa616438d8',1,'task_manager']]]
];
