var searchData=
[
  ['pose_5fof_5fblock',['pose_of_block',['../controller__baxter_8cpp.html#acd223f9980b78fd9cd94f79c8d46a829',1,'controller_baxter.cpp']]],
  ['print_5ftask',['print_task',['../task__manager_8py.html#a608c2ff029d8acc186e4a83c38146e6c',1,'task_manager']]]
];
