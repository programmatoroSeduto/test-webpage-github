var searchData=
[
  ['on_5fshutdown_5fmsg',['on_shutdown_msg',['../task__manager_8py.html#aa5609aceebe3e9ed3d8e8c0e136b958a',1,'task_manager']]]
];
