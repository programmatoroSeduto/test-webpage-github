var searchData=
[
  ['task_5fmanager_2epy',['task_manager.py',['../task__manager_8py.html',1,'']]]
];
