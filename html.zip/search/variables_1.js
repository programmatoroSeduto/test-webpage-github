var searchData=
[
  ['update_5fcounter',['update_counter',['../task__manager_8py.html#a85cab93f0dcd43494871852cead5ce1a',1,'task_manager']]]
];
