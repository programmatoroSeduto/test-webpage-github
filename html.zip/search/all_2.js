var searchData=
[
  ['dist_5fblock_5fhand',['dist_block_hand',['../task__manager_8py.html#a7767c472cd1a818300404acd098bc21d',1,'task_manager']]],
  ['distance_5fbetween',['distance_between',['../task__manager_8py.html#ad79509d41a6e76c386a90dea02a7746c',1,'task_manager']]]
];
