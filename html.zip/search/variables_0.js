var searchData=
[
  ['frame_5fhuman_5fhand_5fright',['frame_human_hand_right',['../task__manager_8py.html#ad9df2ebdea2ae78851f40e4a303e78aa',1,'task_manager']]]
];
