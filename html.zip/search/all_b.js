var searchData=
[
  ['server_5fcallback',['server_callback',['../baxter__at__home_8cpp.html#a5a7d60ef32b07038c6006769d0a749ef',1,'server_callback(controller_baxter::at_home::Request &amp;req, controller_baxter::at_home::Response &amp;res):&#160;baxter_at_home.cpp'],['../controller__baxter_8cpp.html#a44bd045dfd45dc008b5ca1f95cbdf199',1,'server_callback(controller_baxter::command::Request &amp;req, controller_baxter::command::Response &amp;res):&#160;controller_baxter.cpp']]],
  ['stampa_5fpose',['stampa_Pose',['../controller__baxter_8cpp.html#af015133be382f52b0fc82683e03f931c',1,'controller_baxter.cpp']]]
];
